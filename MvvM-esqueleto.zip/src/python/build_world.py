# future script to build world
