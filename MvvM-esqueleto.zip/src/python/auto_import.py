import os, zipfile, json, pathlib, shutil

DATA_DIR = pathlib.Path("data")

def extract_zip(zip_path, extract_to="temp/"):
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_to)
    return pathlib.Path(extract_to)

def normalize_and_classify(input_file, output_dir):
    with open(input_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("PERS:"):
                save_line(line[5:].strip(), output_dir / "personagens" / "characters_auto.jsonl", "personagem")
            elif line.startswith("LOC:"):
                save_line(line[4:].strip(), output_dir / "locais" / "locations_auto.jsonl", "local")
            elif line.startswith("ITEM:"):
                save_line(line[5:].strip(), output_dir / "itens" / "items_auto.jsonl", "item")

def save_line(content, output_file, tipo):
    obj = {"type": tipo, "data": content}
    output_file.parent.mkdir(parents=True, exist_ok=True)
    with open(output_file, "a", encoding="utf-8") as out:
        out.write(json.dumps(obj, ensure_ascii=False) + "\n")

def process_zip(zip_file):
    temp_dir = extract_zip(zip_file)
    for txt in temp_dir.rglob("*.txt"):
        normalize_and_classify(txt, DATA_DIR)
    shutil.rmtree(temp_dir)

def scan_existing_files():
    for path in pathlib.Path('.').rglob('*'):
        if path.is_file() and not str(path).startswith(('src','docs','web','.github')):
            if path.suffix in ['.txt', '.json', '.jsonl']:
                normalize_and_classify(path, DATA_DIR)
                path.unlink()

if __name__ == "__main__":
    # process existing zips
    for zip_path in pathlib.Path('.').glob("*.zip"):
        process_zip(zip_path)
        zip_path.unlink()
    # scan repo for loose files
    scan_existing_files()
