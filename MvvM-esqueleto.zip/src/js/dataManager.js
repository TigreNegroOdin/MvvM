// future frontend data manager
