# 📜 Leis Fundamentais

- [LEI:B-001-001] Detalhe é Vida: Cada partícula tem ID único.
- [LEI:B-001-002] Coerência: Versão raiz prevalece.
- [LEI:B-001-003] Existência Fixa: Nada surge após o Marco Zero.
