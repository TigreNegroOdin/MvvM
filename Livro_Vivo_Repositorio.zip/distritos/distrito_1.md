# Distrito 1 — Registro Inicial

Exemplo de pessoas, locais e objetos.

- [LOC-D1-000001] Mercado_DoMar_1
- [PERS:P-D1-000001] Nicole Oliveira, 70 anos, motoboy.
