# Evento: Fome

A fome é medida em cada distrito e registrada de forma persistente.
