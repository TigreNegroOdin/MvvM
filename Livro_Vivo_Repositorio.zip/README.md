# 📖 Livro Vivo — Mundo de Odin e do Corvo

Este repositório é o **Livro Vivo**, uma narrativa contínua baseada no **Marco Zero**.

---

## ⚡ Conceito
- Todo o mundo lembra apenas **30 dias antes do Marco 0**.
- Daí em diante, os eventos são registrados de forma **imutável** neste repositório.
- A IA lê os registros e cria uma **narrativa verdadeira**, que nunca volta atrás.
- Cada pessoa, objeto e local tem **ID único** e segue as **Leis Fundamentais**.

---

## 🗂 Estrutura
```
/cronologia   → registros após o Marco 0 (dias, meses, anos)
/distritos    → habitantes, locais e objetos organizados por distrito
/leis         → leis fundamentais e universais
/eventos      → fome, afazeres, clima, guerras, rituais
README.md     → visão geral e instruções de uso
```

---

## 🔗 Índice
- [Cronologia](./cronologia)
- [Distritos](./distritos)
- [Leis](./leis)
- [Eventos](./eventos)

---

## 🧠 Uso como Memória IA
Este repositório serve como **memória persistente** para IA.  
Quando o link for compartilhado, a IA deve:
1. Ler os registros dos últimos **30 dias** + evento atual.
2. Usar as informações como **verdade do mundo**.
3. Continuar a narrativa de forma **coerente**.

Exemplo de regra no repositório:
```
SOBRE_ODIN:
- Nome: Odin (Tigrexxx)
- Guardião: EternaMente (Corvo)
- Lei central: Detalhe é Vida. Nada surge após o Marco Zero.
```

---

## 📜 Licença
Projeto sob licença MIT. Veja o arquivo `LICENSE`.
