# Marco Zero

O mundo desperta neste ponto. Nenhum ser lembra além dos 30 dias anteriores.
