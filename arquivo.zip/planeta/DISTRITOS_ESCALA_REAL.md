# 🌍 MATRIZ DE DISTRITOS MVVM — ESCALA GLOBAL E LÓGICA ATUALIZADA

---

## 1. DISTRITOS E SUAS REFERÊNCIAS

| Distrito | Equivalente | Área (aprox.) | População (estimada, lógica) | Perfil/Cultura |
|----------|-------------|---------------|------------------------------|----------------|
| D1       | EUA         | 9.800.000 km² | 330.000.000                  | Superpotência, diversidade, cidades globais, interior rural, inovação, facções e máfias, cultura pop, múltiplos sotaques. |
| D2       | África      | 30.000.000 km²| 1.300.000.000                | Diversidade étnica/natural, desertos, savanas, megacidades, tribos, tradição, riqueza mineral, rotas de migração. |
| D3       | Brasil      | 8.500.000 km² | 210.000.000                  | Urbano/rural, florestas, favelas, metrópoles, festas, desigualdade, facções, natureza, economia mista. |
| D4       | RJ          | 43.000 km²    | 17.000.000                   | Praias, cidades médias, cultura de praia e morro, carnaval, turismo, facções, contrastes sociais. |
| D5       | EUA (Mega)  | 9.800.000 km² | 330.000.000                  | Megacidade global, alta densidade, inovação, crime global, multiculturalismo, tecnologia. |
| D6       | Paris       | 100 km²       | 2.200.000 (12M metropolitana)| Centro cultural, artístico, intelectual, moda, imigração, vida noturna, protestos. |
| D7       | Espírito Santo (ES) | 46.000 km² | 4.000.000                   | Litoral diversificado, montanhas, cidades médias, cultura capixaba, pesca, agricultura, festas religiosas, imigração italiana, tranquilidade, potencial de portos. |

---

## 2. NOTAS SOBRE D7 (ES)

- **Geografia:** Litoral extenso, montanhas, cidades costeiras (Vitória, Vila Velha), interior agrícola forte.
- **Cultura:** Festa da Penha, congo capixaba, moqueca, influência italiana, festas de pescadores, culinária forte, tradição católica, carnaval de rua.
- **Economia:** Portos estratégicos, pesca, agricultura (café, mamão, pimenta), indústrias pequenas/médias, turismo de praia e serra.
- **Sociedade:** Mistura de urbano e rural, cidades médias bem estruturadas, baixo índice de violência comparado ao RJ, mas com áreas de risco e influência de facções.
- **Interatividade:** Praias, morros, portos, bairros pesqueiros, festas tradicionais, trilhas nas montanhas, rotas marítimas.

---

## 3. EXEMPLO DE ARQUIVO DE DISTRITO D7

````markdown name=planeta/D7/INFO.md
# Distrito D7 — Espírito Santo (ES)

- Área: 46.000 km²
- População: 4.000.000 habitantes
- Cidades principais: Vitória (capital), Vila Velha, Serra, Cariacica, Linhares, Cachoeiro de Itapemirim
- Economia: Portos, pesca, agricultura, indústrias, turismo
- Cultura: Festa da Penha, moqueca capixaba, congo, influência italiana, festas religiosas e de pescadores
- Ambiente: Litoral, montanhas, cidades médias, interior agrícola
- Rotas principais: BR-101, BR-262, portos marítimos, estradas vicinais, trilhas de serra
- Facções e máfias: Presença moderada, focos em portos e regiões de periferia urbana
- Pontos de interesse: Convento da Penha, praias de Guarapari, Pedra Azul, Ilha das Caieiras, estação de trem Vitória-Minas, manguezais da baía de Vitória