# 🌍 MVVM — MATRIZ PLANETÁRIA SOB O DOMO

---

## 1. ESTRUTURA GERAL DO PLANETA

- **O domo circunda todo o planeta.**  
- O planeta é dividido em Distritos (“D1” a “Dn”), cada um funcionando como país autônomo.
- **Todos os elementos (habitantes, casas, facções, partículas, objetos, veículos, eventos, etc.) possuem ID, localização, histórico e estado.**
- **Nada existe fora do domo.**
- **A escala planetária inclui:**
  - Macro-regiões (distritos)
  - Micro-regiões (bairros, ruas, praias, zonas rurais)
  - Elementos naturais e artificiais (florestas, rios, cidades, praias, fábricas, etc.)
  - Rotações, estradas, redes de transporte, clima, memória ambiental

---

## 2. DISTRITOS PRINCIPAIS (EXEMPLO)

### D1 — Central
- Centro urbano, hub econômico, turístico, sede do poder civil/policial.
- Rotatória central conecta rodovias, praias (D2, D4), rodoviária, comércio.
- Facções: CV, ADA, TCP, Milícia, PCC (controle de rotas, influência local).

### D2 — Praia
- Zona litorânea, bares, turismo, casas de praia, rotas de transporte para D1 e D4.

### D3 — Indústria & Máfia
- Parques industriais, logística, sedes de famílias mafiosas (Valentini, O’Connor, Radu).
- Rotas interestaduais, influência sobre D4.

### D4 — Turquia & Rua do Tigre
- Bairro misto (urbano/rural), escolas, mercadinho, pracinha, casas habitadas e abandonadas.
- Rede social infantil (Murilo, Nicole, Enzo, etc), facções infiltradas, máfias, submundo local.

---

## 3. ESCALA POPULACIONAL & INFRAESTRUTURA

- **População:**  
  - Núcleos familiares, vizinhanças, crianças, adultos, idosos, classes sociais, submundo, autoridades.
  - Rede social infantil na Rua do Tigre como elo entre famílias e facções.

- **Habitações:**  
  - Casas urbanas, casas de praia, casas rurais, casas em obra, abandonadas, pontos estratégicos.

- **Infraestrutura:**  
  - Ruas pavimentadas, estradas de barro, rotatórias, pontes, praças, terreno baldio, escolas, mercadinho, bares, fábricas.
  - Veículos: carros, motos, vans, caminhões, barcos.

- **Objetos e Inventários:**  
  - Doméstico (geladeira, rádio, móveis, etc.)
  - Profissional (ferramentas, armas, produtos agrícolas/industriais)
  - Pessoal (celular, brinquedos, estojo de bala, dinheiro, documentos)

- **Partículas e Ambiente:**  
  - Areia de praia, vento, folhas, chuva, poeira.  
  - Cada elemento natural tem ID e memória de localização/movimento.

---

## 4. FACÇÕES, MÁFIAS, GRUPOS

- **Facções** (CV, ADA, TCP, Milícia, PCC): controle de rotas, pontos de venda, influência social.
- **Máfias** (Valentini, O’Connor, Radu): lavagem, contrabando, tráfico humano, infiltração em negócios.
- **Submundo Local:** ladrões, hippies, comerciantes, rede de favores/ameaças.

---

## 5. MECÂNICAS PLANETÁRIAS

- **Movimentação:**  
  - Todo deslocamento é rastreado (habitante, objeto, partícula), com histórico e motivo.
  - Riscos por rota (checkpoints, bocas, vigias).
- **Memória universal:**  
  - Cada entidade (pessoa, objeto, partícula) registra sua história: onde esteve, quando, por quê, com quem interagiu.
- **Inventário:**  
  - Visível (público, fiscalizável) e invisível (escondido, secreto).
- **Classes sociais:**  
  - Civis, força pública, submundo, facções, máfias.

---

## 6. EXEMPLOS DE ESCALA PLANETÁRIA

### [D1] Avenida Central
- Estende-se do Centro Urbano até a Rotatória Central.
- Casas: 1 a 5000, com variedade de moradores (comerciantes, policiais, civis, agentes do submundo).

### [D4] Rua do Tigre
- 47 casas, núcleo da narrativa, divisão entre habitadas, abandonadas, em obra.
- Pracinha, terreno baldio, ponte para bairro Turquia.
- Crianças (Murilo, Nicole, Enzo, etc.) = rede social e ponto de ligação entre distritos.

### [Partícula] AREIA-D2-000001
- Localização: Praia D2, coordenada -23.555001,-46.630501,0
- Histórico:  
  - [2025-09-06T15:14:00Z] Movido por vento PART-D2-000001
  - [2025-09-06T15:16:00Z] Pisado por PERS-D4-MURILO-001
  - [2025-09-06T15:18:00Z] Levado para CASA-D4-00003

---

## 7. CAMADAS

- **Raiz (detalhe total):**  
  - Cada entidade tem ID, nome, localização atual, histórico completo, estado, vínculos, motivo de cada mudança.
  - Exemplo: casa, praia, objeto, partícula, grupo, evento.
- **Superfície (visível ao jogador):**  
  - Apenas o resumo relevante, de acordo com o contexto do personagem.

---

**O planeta MVVM está integralmente registrado sob o domo:  
Nada se perde, tudo pode ser consultado, expandido e auditado.  
A escala é planetária — do grão de areia à máfia internacional.**
