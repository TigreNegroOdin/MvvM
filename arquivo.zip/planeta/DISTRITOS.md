# DISTRITOS DO PLANETA MVVM

---

## D1 — Central
- Núcleo urbano, econômico e turístico.
- Centro do poder; rotatória central, rodoviária, comércio.
- Polícia (estilo EUA), facções (CV, ADA, TCP, Milícia, PCC).
- Conecta com D4 (via rodovia e rotas clandestinas).

## D2 — Praia
- Zona litorânea, bares, turismo, casas de praia.
- Importante para lazer e rotas alternativas.

## D3 — Indústria & Máfia
- Parque industrial, logística pesada.
- Sede das máfias (Valentini, O’Connor, Radu).
- Rotas interestaduais e influência no submundo.

## D4 — Turquia & Rua do Tigre
- Bairro misto (urbano/rural/praia), escolas, mercadinho, pracinha.
- Rua do Tigre: 47 casas (habitadas, em obra, abandonadas).
- Facções infiltradas, máfias, rede social infantil, submundo caipira.
- Pontezinha conecta à praia e ao bairro Turquia.

---

## Observações Gerais

- Cada distrito tem subdivisões: bairros, ruas, casas, pontos estratégicos.
- Interligações por rodovias, estradas de barro (clandestinas), rotatórias, pontes.
- Facções, máfias, polícias, comerciantes e civis transitam entre distritos.
- Toda pessoa, casa, objeto, veículo, partícula, evento é registrada com ID e memória.

---

**O mundo MVVM está organizado em distritos, cada um com suas características, população, infraestrutura e conflitos.  
Tudo sob o domo, tudo rastreável, tudo pronto para ser expandido.**