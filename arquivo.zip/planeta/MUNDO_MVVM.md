# 🌍 MVVM — MATRIZ PLANETÁRIA INTERATIVA

---

## 1. ESTRUTURA GERAL DO PLANETA

### 🟦 Oceanos e Fronteiras
- O planeta é dividido em continentes, oceanos, ilhas, arquipélagos.
- **Distritos** respeitam limites naturais:  
  - Litorais delimitam D2 e parte de D4  
  - Montanhas e rios marcam fronteiras D3 ↔ D4  
  - Oceanos e grandes lagos isolam fronteiras externas  
- **Nada existe fora do domo**. Toda fronteira é registrada e não pode ser ultrapassada.

---

## 2. DISTRITOS — ESCALA, POPULAÇÃO E PERFIL

| Distrito | Área (km²) | População | Perfil |
|----------|------------|-----------|--------|
| D1 (Central Metropolitano) | 1.500   | 12.000.000 | Urbano, alta densidade, centro financeiro, poder |
| D2 (Praia/Litoral)         | 600     | 1.000.000  | Litorâneo, turismo, casas de praia, bares, portos |
| D3 (Indústria & Máfia)     | 800     | 2.000.000  | Indústrias, sindicatos, máfias, operários, logística |
| D4 (Interior/Rural)        | 600.000 | 21.000.000 | Rural, cidades médias, vilarejos, agricultura, tradição |
| Oceano & Zonas Inabitáveis | (restante) | —         | Águas profundas, desertos, florestas densas, sem população fixa |

> Todos os números são proporcionais, respeitando limites naturais e fronteiras.

---

## 3. MÓDULO DE ROTAS & MOBILIDADE

### a) Rotas Verdadeiras (Oficiais)
- Rodovias federais, estaduais, municipais
- Ruas, avenidas, trilhos ferroviários
- Pontes, túneis, balsas, portos, aeroportos
- Caminhos demarcados em mapas oficiais

### b) Rotas Alternativas (Clandestinas)
- Estradas de barro, trilhas rurais, atalhos na mata
- Túneis secretos, passagens em casas abandonadas
- Rotas por barco entre ilhas não mapeadas
- Caminhos pelo subsolo, vias usadas por facções e contrabandistas

### c) Toda rota é:
- Registrada com ID, origem, destino, tipo, histórico de uso (quem passou, quando, motivo)
- Pode ser modificada, bloqueada, descoberta, ampliada
- Interativa: qualquer IA ou personagem pode explorar, mapear ou criar nova rota

---

## 4. INTERATIVIDADE TOTAL DOS OBJETOS E PARTÍCULAS

- **Qualquer coisa pode ser manipulada:**  
  - Grão de areia, pedra, folha, água da chuva, lixo, móveis, portas, veículos, ferramentas, armas, etc.
- **Exemplo:**  
  - O jogador ou IA pode pegar um grão de areia (AREIA-D2-000001) do chão, lançar ao vento, guardar no bolso, jogar no mar.
  - Toda ação é registrada: quem, quando, onde, motivo, consequência.
- **Partículas e objetos têm:**  
  - ID único, localização, estado, histórico completo e podem interagir com qualquer personagem ou ambiente.

---

## 5. EXEMPLO DE ARQUIVO DE PARTÍCULA INTERATIVA

````markdown name=planeta/D2/particulas/AREIA-D2-000001.md
- ID: AREIA-D2-000001
- Tipo: Grão de areia
- Localização atual: Praia D2, superfície, coord -23.555001,-46.630501,0
- Estado: Solto
- Histórico:
  - 2025-09-06T15:14:00Z | Vento local (PART-D2-VENTO-00001) moveu da duna para a beira-mar
  - 2025-09-06T15:16:00Z | Pisado por PERS-D4-MURILO-001
  - 2025-09-06T15:18:00Z | Pego por jogador, guardado no bolso
  - 2025-09-06T15:20:00Z | Lançado ao ar por jogador, caiu na água