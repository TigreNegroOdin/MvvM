# DOMO UNIVERSAL MVVM — MATRIZ RAIZ

---

## 1. DISTRITOS E GEOGRAFIA

### D1 — Central
- Urbano, núcleo econômico, turístico, centro do poder.
- Prédios, comércio, rodoviária.
- Polícia estilo EUA (FBI, SWAT), forças públicas corruptíveis.
- Facções: CV, ADA, TCP, Milícia, PCC (bases, operações, influência).
- Rotatória central, rodovia interestadual (ligação entre distritos).
- Rotas pavimentadas (tráfego civil/comercial) e estradas de barro (atalhos clandestinos).

### D2 — Praia
- Turismo, bares, costa, atividades ligadas ao mar.
- Estradas conectam à rotatória central e ao D4.

### D3 — Indústria & Máfia
- Indústria pesada, logística, base de famílias mafiosas (Valentini, O’Connor, Radu).
- Conexão com mundo do crime organizado internacional.
- Proximidade estratégica com o D4.

### D4 — Turquia & Rua do Tigre (semi-rural, praia)
- Bairro misto, escolas, mercadinho, serviços básicos, semi-rural, luz/água/esgoto.
- Rua do Tigre: 47 casas (habitadas, inacabadas, abandonadas ou só terreno).
- Sem hospital, polícia estilo Brasil (corrupta, pouco efetivo), delegacia precária.
- Pontezinha conecta à praia e ao bairro Turquia.
- Pracinha, terreno baldio, casas estratégicas (abandono, obra, fachada, esconderijo).
- Núcleos sociais: Casa do Tigre, Casa da Lucy, vizinhos, pontos-chave.

---

## 2. POPULAÇÃO (EXEMPLO: RUA DO TIGRE, D4)

### Núcleo 1: Casa do Tigre
- Tigre: recém-chegado, central da narrativa.
- Carol: esposa.
- Filhos:
  - Murilo (10 anos): esperto, curioso, explora casas abandonadas, coleciona segredos.
  - Nicole (7 anos): sensível, imaginativa, brinca na pracinha, elo com filha do médico.
  - Gael (3 anos): bebê, percebe tensões, socializado pela vizinhança.

### Núcleo 2: Casa da Lucy
- Lucy: mãe solo, relação com Alace (contrabando).
- Rogério: ex-parceiro violento.
- Filhos:
  - Enzo (14 anos): rebelde, olheiro do CV.
  - Filha do meio (11 anos): dedicada, desconfiada, filha do médico do D1.
  - Filho mais novo (5 anos): tímido, vítima de violência doméstica.

### Núcleo 3: Vizinhos imediatos
- Vizinho 1: senhor aposentado (fofoqueiro).
- Vizinho 2: casal jovem (donos do mercadinho).
- Vizinho 3: casa abandonada (esconderijo de facção, boatos).
- Vizinho 4: casa em obra (movimento irregular, possível fachada).

### Núcleo 4: Pontos estratégicos
- Pracinha (pontezinha): crianças brincam, elo social.
- Terreno baldio: campo de futebol, reuniões rápidas de traficantes.
- Casas em obra/abandono: estratégicas para operações e observação.

---

## 3. FACÇÕES, MÁFIAS E GRUPOS LOCAIS

### Facções D1
- CV (Comando Vermelho): drogas sintéticas/cocaína, jovens olheiros (ex: Enzo).
- ADA (Amigos dos Amigos): crack, bocas, soldados jovens (11-15), infiltração em casas abandonadas.
- TCP: maconha, contrabando, influência em bares, tenta cooptar comerciantes.
- Milícia: proteção clandestina, extorsão, gás/internet pirata.
- PCC: logística de armas, rotas interestaduais, uso de estradas de barro.

### Máfia D3
- Valentini (Italiana): lavagem de dinheiro, restaurantes de fachada.
- O’Connor (Irlandeses): contrabando de armas, depósitos secretos.
- Radu (Romena): tráfico humano, dívidas, laço com adolescentes.

### Grupos D4
- Submundo caipira, hippies (tentam plantar cannabis), comerciantes locais (rede invisível).

---

## 4. MECÂNICAS E SOCIEDADE

- Classes sociais: civis, força pública, submundo, facções, máfias.
- Inventários: visível (carros, roupas, móveis), invisível (segredos, objetos escondidos).
- Checkpoints, risco em cada rota, memória estratégica dos lugares visitados.
- Crianças — tecido invisível social, elo entre núcleos, usadas como álibi, rede de informação.

---

## 5. MEMÓRIA E REGISTRO POR ENTIDADE

Cada entidade (pessoa, família, casa, objeto, partícula, veículo):
- ID único
- Nome, papel/social, vínculos familiares/sociais
- Localização atual, histórico (quem/onde/quando/porquê)
- Inventário (visível/invisível) e estado
- Toda ação/interação registrada na memória do objeto/pessoa/local

---

## 6. EXEMPLO DE REGISTRO (RAIZ)

### [PERS-D4-TIGRE-0001] Tigre
- Casa: CASA-D4-00001
- Família: Carol (esposa), Murilo (10), Nicole (7), Gael (3)
- Inventário: OBJ-D4-0001 (carro velho), OBJ-D4-0002 (estojo de bala), OBJ-D4-PRF-0001 (ferramentas)
- Histórico: 
  - 2025-09-06T17:00Z mudou-se para Rua do Tigre.
  - 2025-09-06T17:32Z Murilo encontrou estojo de bala, escondeu em casa.

### [CASA-D4-00001] Casa do Tigre
- Endereço: Rua do Tigre, nº 1
- Estado: habitada, recém-reformada
- Moradores: Tigre, Carol, Murilo, Nicole, Gael
- Inventário: móveis básicos, itens pessoais

### [OBJ-D4-0002] Estojo de bala
- Localização: escondido em CASA-D4-00001
- Último movimento: encontrado por Murilo
- Histórico: 
  - 2025-09-06T18:00Z deixado numa casa abandonada por traficante CV
  - 2025-09-06T19:00Z encontrado por Murilo

### [PERS-D4-LUCY-0001] Lucy
- Casa: CASA-D4-00002
- Parceiro: Alace (contrabando)
- Filhos: Enzo (olheiro CV), filha do médico (11), filho mais novo (5)
- Histórico: 
  - Violência doméstica registrada, relação com O’Connor (Irlandeses)

---

## 7. REGRAS DO DOMO

- Nada existe sem ID e memória.
- Toda ação, movimento, segredo, descoberta ou perda é registrada na camada raiz.
- Jogador recebe versão simplificada; Corvo/IA mantém todos os detalhes.

---

**O mundo está estruturado, interligado e pronto para consultas, expansão ou automação — sempre dentro do domo!**
