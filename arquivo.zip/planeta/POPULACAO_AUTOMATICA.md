# 🌍 MVVM — POPULAÇÃO AUTOMÁTICA POR DISTRITO (PIB, IBGE, DENSIDADE)

---

## 1. ALGORITMO DE CÁLCULO

- **População = Área x Densidade média IBGE/ONU**
- **PIB do distrito define padrão de vida, escolaridade, profissão, tipo de moradia e estrutura**
- **Cada habitante é um arquivo único (com ID, endereço, profissão, rotina, família, histórico e laços sociais)**

---

## 2. EXEMPLO DE PARÂMETROS POR DISTRITO (escala real)

| Distrito | Área (km²) | Densidade (hab/km²) | População calculada | PIB (proporcional) |
|----------|------------|---------------------|---------------------|--------------------|
| D1 (EUA) | 9.800.000  | 36                  | 352.800.000         | Muito alto         |
| D2 (África) | 30.000.000 | 43               | 1.290.000.000       | Médio/Baixo        |
| D3 (Brasil) | 8.500.000 | 25                | 212.500.000         | Médio              |
| D4 (RJ) | 43.000      | 375                 | 16.125.000          | Alto               |
| D5 (Mega EUA) | 9.800.000 | 36              | 352.800.000         | Muito alto         |
| D6 (Paris) | 100        | 21.000             | 2.100.000           | Muito alto         |
| D7 (ES) | 46.000      | 87                  | 4.002.000           | Médio              |
| **Total** | —          | —                   | **2.230.327.000**   | —                  |

> *Valores arredondados e ajustados conforme IBGE, ONU e PIB local.*

---

## 3. GERADOR DE HABITANTES E ARQUIVOS

### Cada habitante recebe:
- ID único: `PESSOA-{DISTRITO}-{NUMERO}`
- Endereço: distrito, cidade, rua, lote, casa/apto
- Família: relação de pais, filhos, cônjuge
- Profissão: conforme PIB, escolaridade e economia local
- Rotina: horários, trabalho, lazer, deslocamento
- Histórico: nascimento, mudanças, eventos marcantes
- Laços sociais: amigos, vizinhos, colegas de escola/trabalho

---

### EXEMPLO DE ESTRUTURA GERADA

```
planeta/
  D1/
    habitantes/
      PESSOA-D1-00000001/
        identidade.md
        memoria.md
        rotina.md
      PESSOA-D1-00000002/
        ...
    lotes/
      LOT-D1-00000001/
        memoria.md
      ...
  D2/
    habitantes/
      PESSOA-D2-00000001/
        ...
  ...
```

---

#### Exemplo de habitante (D1, urbano, alta renda):

````markdown name=planeta/D1/habitantes/PESSOA-D1-00000001/identidade.md
- ID: PESSOA-D1-00000001
- Nome: Anthony Carter
- Idade: 42
- Profissão: Engenheiro de Software
- Escolaridade: Doutorado
- Endereço: Avenida Central, nº 123, Apto 901
- Família: esposa (Marie), 2 filhos
- PIB distrito: Muito alto
- Rotina: Trabalho remoto, academia, lazer com família