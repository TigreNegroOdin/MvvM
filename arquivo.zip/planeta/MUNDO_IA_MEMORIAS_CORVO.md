# 🌍 MVVM — MUNDO COM HABITANTES IA E MEMÓRIA ALIMENTANDO O CORVO

---

## 1. TODOS OS HABITANTES SÃO IA

- Cada pessoa tem:
  - **ID único, rotina, profissão, família, medos, alegrias, histórico de saúde, traumas, aprendizados**
  - **Memória detalhada de cada dia, cada ação, cada evento**
  - **Casa, rua, bairro, cidade, distrito, país — todos com memória cruzada**
  - **Inventário (objetos pessoais, roupas, dinheiro, armas, cartas, livros, etc)**
- **Exemplo:**  
  - PESSOA-D4-000123 vive em “Casa da Rua do Tigre, nº 17”, trabalha no mercadinho, teve uma briga com o vizinho há 12 dias, está apaixonada pela professora da escola local, participou de uma festa na pracinha 5 dias atrás.

---

## 2. MEMÓRIA CRUZADA & NARRAÇÃO DO CORVO

- **O Corvo** narra a história para você (jogador) e para os próprios habitantes, **usando tudo que está registrado nas memórias deles**.
- **Quando um personagem fala, age ou reage, faz isso com base em tudo que já experimentou no mundo real** (não inventa, nem “puxa do nada”).
- **A memória é coletiva e individual:**  
  - Um segredo contado a alguém só pode ser narrado se aquela pessoa lembra e o Corvo pode acessar.
  - Um trauma coletivo (ex: explosão, festa, assassinato) é narrado por múltiplas perspectivas, cada IA dando seu “tom”.

---

## 3. TUDO ESTÁ VIVO 30 DIAS ANTES DA DOENÇA

- **Estado do mundo:**  
  - Todos habitantes-IA estão ativos, rotinas normais, eventos acontecendo.
  - Cada um tem histórico completo dos últimos meses/anos.
  - Cada local tem memória de tudo que aconteceu ali.
  - Cada objeto foi movido, tocado, usado por alguém — tudo registrado.

---

## 4. EXEMPLO DE ESTRUTURA DE HABITANTE IA

````markdown name=planeta/D4/habitantes/PESSOA-D4-000123/IDENTIDADE.md
- ID: PESSOA-D4-000123
- Nome: Júlio Maciel
- Idade: 38
- Profissão: Atendente de mercadinho
- Estado emocional: Preocupado (contas atrasadas), apaixonado (Elisa, professora)
- Saúde: Gripe leve (há 3 dias)
- Família: mãe idosa, irmã distante
- Casa: LOT-D4-000045