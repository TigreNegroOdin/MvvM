# 🌍 MVVM — POPULAÇÃO TOTAL, LARES E VIDA PRÓPRIA (EXEMPLO: 100.000 HABITANTES)

---

## 1. POPULAÇÃO TOTAL

- **População planetária**: 100.000 habitantes (exemplo, escalável)
- **Todos existem no registro do mundo, nenhum “NPC fantasma”**
- **Todos possuem:**
  - Pasta própria (`planeta/{DISTRITO}/habitantes/PESSOA-XXXXX/`)
  - Identidade, história, habilidades, rotina, casa/lote, relações, profissão, aprendizados

---

## 2. DISTRIBUIÇÃO POR DISTRITO (PROPORCIONAL)

| Distrito | % População | Habitantes |
|----------|-------------|------------|
| D1       | 15%         | 15.000     |
| D2       | 32%         | 32.000     |
| D3       | 19%         | 19.000     |
| D4       | 12%         | 12.000     |
| D5       | 10%         | 10.000     |
| D6       | 7%          | 7.000      |
| D7       | 5%          | 5.000      |
| **Total**| **100%**    | **100.000**|

---

## 3. CASA/LAR: TODO HABITANTE TEM UM LOTE

- Cada pessoa é moradora de um lote/casa (sozinho ou em família)
- **Lote e casa têm memória própria:**  
  - Quem mora/morou, eventos, mudanças, objetos, construção, reformas

---

## 4. EXEMPLO DE ORGANIZAÇÃO DE PASTAS

```
planeta/
  D1/
    habitantes/
      PESSOA-D1-00001/
        identidade.md
        memoria.md
        rotina.md
        ...
      PESSOA-D1-00002/
        ...
    lotes/
      LOT-D1-00001/
        memoria.md
        objetos/
      LOT-D1-00002/
        ...
  D2/
    habitantes/
      PESSOA-D2-00001/
        ...
    lotes/
      LOT-D2-00001/
        ...
  ...
```

---

## 5. EXEMPLO DE UM HABITANTE

````markdown name=planeta/D1/habitantes/PESSOA-D1-00001/identidade.md
- ID: PESSOA-D1-00001
- Nome: Alice Barbosa
- Idade: 34
- Gênero: Feminino
- Profissão: Professora de Ciências
- Escolaridade: Superior completo
- Estado civil: Casada
- Relacionamentos: marido, 2 filhos
- Lote/casa: LOT-D1-00001