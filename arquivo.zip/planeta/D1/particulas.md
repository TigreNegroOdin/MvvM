## [PART-D1-000002]
- Tipo: Vento
- Intensidade: Fraca
- ID: PART-D1-000002
- Coordenadas atuais: -23.550800, -46.634000, 750
- Localização atual: Praça Central do D1
- Histórico:
  - Soprou das coordenadas -23.550700, -46.633900, 749 às 2025-09-06T17:00:00Z
  - Empurrou AREIA-D1-000001 para nova posição
- Estado: Dissipado em 2025-09-06T17:05:00Z