# OBJETOS DO DISTRITO D1

## [ITEM-D1-000001]
- Tipo: Rádio
- Modelo: Radio-652
- Estado: Rachado
- Local: CASA-D1-000001
- Possível dono: PERS-D1-000001

## [ITEM-D1-000002]
- Tipo: Kit Médico
- Modelo: KitMedico-851
- Estado: Usado
- Local: CASA-D1-000002
- Possível dono: PERS-D1-000002

## [ITEM-D1-000003]
- Tipo: Livro
- Modelo: Didático
- Estado: Novo
- Local: CASA-D1-000003
- Possível dono: PERS-D1-000003

## [ITEM-D1-000004]
- Tipo: Laptop
- Modelo: MVVMBook Ultra
- Estado: Usado
- Local: CASA-D1-000003
- Possível dono: PERS-D1-000003

---