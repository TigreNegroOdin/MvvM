# RUAS DO DISTRITO D1

## [RUA-D1-000001]
- Nome: Avenida Central
- Tipo: Avenida
- Número inicial: 1
- Número final: 5000
- Casas: CASA-D1-000001 a CASA-D1-005000
- Estado: Pavimentada

## [RUA-D1-000002]
- Nome: Rua das Palmeiras
- Tipo: Rua
- Número inicial: 1
- Número final: 800
- Casas: CASA-D1-005001 a CASA-D1-005800
- Estado: Arborizada

---