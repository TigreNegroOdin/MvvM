# LOCAIS DO DISTRITO D1

## [LOC-D1-0001]
- Nome: Praça Central do D1
- Descrição: Praça arborizada, bancos de concreto, coreto central e fonte desativada. Frequentada por idosos e crianças.
- Coordenadas aproximadas: -23.550520,-46.633308,750
- Eventos: EVENTO-D1-000001
- Habitantes próximos: PERS-D1-000001, PERS-D1-000002

---