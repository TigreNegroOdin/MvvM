# LEIS FUNDAMENTAIS E DE IDENTIDADE PLANETÁRIA — MVVM

## 1. Lei da Identidade Planetária
- Tudo que existe recebe ID único e nome ao ser criado.
- IDs seguem padrão: D1, D2, ..., PERS-D1-000001, RUA-D1-000001, CASA-D1-000001, etc.
- Nomes são únicos dentro do distrito.
- Toda entrada: ID, nome, tipo, localização, data, status, vínculos.

## 2. Lei do Domo
- O planeta é cercado por um domo invisível.
- Nada existe fora do domo: não há fuga, não há além.
- A borda é absoluta, indetectável por sentidos comuns.

## 3. Lei da Memória
- Tudo é registrado no Corvo.  
- Nada se perde, tudo pode ser consultado.

## 4. Lei da Camada Odin
- Criações de Odin são raiz/canônicas.
- Dados IA só preenchem o que faltar para fechar a matriz.
- Em caso de conflito, sempre prevalece a camada Odin.

## 5. Leis de Expansão
- População, objetos, partículas e eventos podem ser criados infinitamente, seguindo padrão de ID e detalhamento.

---