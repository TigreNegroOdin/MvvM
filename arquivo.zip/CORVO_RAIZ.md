# CORVO RAIZ — INDEXADOR UNIVERSAL MVVM

- [LEIS.md](./LEIS.md)
- [planeta/D1/habitantes.md](./planeta/D1/habitantes.md)
- [planeta/D1/ruas.md](./planeta/D1/ruas.md)
- [planeta/D1/casas.md](./planeta/D1/casas.md)
- [planeta/D1/objetos.md](./planeta/D1/objetos.md)
- [planeta/D1/eventos.md](./planeta/D1/eventos.md)
- [planeta/D1/particulas.md](./planeta/D1/particulas.md)
- [planeta/D1/midia.md](./planeta/D1/midia.md)
- [planeta/D1/locais.md](./planeta/D1/locais.md)
- [CORVO_LOG.md](./CORVO_LOG.md)
- [CORVO_CONSOLIDACAO_2025-09-06.md](./CORVO_CONSOLIDACAO_2025-09-06.md)

---

> Para expandir, siga o mesmo padrão para D2, D3, ..., Dn.

---