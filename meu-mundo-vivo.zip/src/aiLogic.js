export const aiLogic = {
  findPersonById(dataset, personId) {
    return dataset.pessoas.find(p => p.id === personId);
  },

  createCoherentNarrative(person) {
    const outputElement = document.getElementById('output');
    if (!person) {
        outputElement.textContent += `\nA IA não encontrou a pessoa solicitada e não pode narrar sua história.`;
        return;
    }

    let narrative = `\nCom base nas lembranças de ${person.nome}, a IA narra:`;
    if (person.lembrancas && person.lembrancas.length > 0) {
      person.lembrancas.forEach((lembranca, index) => {
        narrative += `\n${index + 1}. Ele/Ela ${lembranca}.`;
      });
    } else {
      narrative += `\nNão há lembranças registradas para esta pessoa.`;
    }
    
    outputElement.textContent += narrative;
  }
};