const cache = {};

export const dataManager = {
  async loadData(filePath) {
    if (cache[filePath]) {
      return cache[filePath];
    }
    
    console.log(`Carregando dados do arquivo: ${filePath}`);
    const response = await fetch(filePath);
    const data = await response.json();
    
    cache[filePath] = data;
    return data;
  }
};