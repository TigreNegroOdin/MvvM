import { dataManager } from './dataManager.js';
import { aiLogic } from './aiLogic.js';

async function startMagic() {
  const outputElement = document.getElementById('output');
  outputElement.textContent = "Iniciando a mágica...";
  
  try {
    const mapData = await dataManager.loadData('/data/mapa.json');
    outputElement.textContent += "\nMapa carregado. Sistema pronto.";
    
    const d1Path = mapData.distritos.D1;
    const d1Data = await dataManager.loadData(d1Path);
    
    const person = aiLogic.findPersonById(d1Data, 'PESSOA_0001');
    aiLogic.createCoherentNarrative(person);

  } catch (error) {
    outputElement.textContent += "\nErro ao carregar os dados. Verifique a estrutura dos arquivos.";
    console.error(error);
  }
}

// Inicia a mágica
startMagic();