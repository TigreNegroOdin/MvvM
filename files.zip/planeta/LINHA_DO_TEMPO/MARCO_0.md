# 🧟 Marco 0 — Surto Zumbi & Colapso MVVM

---

## 1. CONTEXTO

- **Ano base**: 2045  
- **População**: 500.000 NPCs  
- **Estrutura**: 7 Estados, 35 Cidades, 140 Bairros, 2.100 Ruas, 125.000 Casas, 130.000 Núcleos Familiares  
- **Distribuição**: Todos NPCs alocados em famílias, casas, rotas urbanas; nada "flutuante"
- **Ambiente**: País-continente cercado por oceano, ilhas perdidas, zonas de cruzeiro, pirataria e naufrágios

---

## 2. DOENÇA ZUMBI (Origem)

- **Dia -30**: Casos misteriosos de febre, isolamento de pacientes em bairros periféricos
- **Dia -25**: Primeiras mortes, sinais de agressividade e retorno dos recém-falecidos
- **Dia -20**: Autoridades declaram estado de emergência, quarentena em cidades grandes
- **Dia -15**: Facções armadas surgem, famílias começam a se refugiar coletivamente
- **Dia -10**: Zonas de quarentena rompidas, zumbis espalham-se por rotas urbanas e rurais
- **Dia -5**: Migração para ilhas, cruzeiros e zonas seguras; piratas do crime atacam navios e portos
- **Dia -1**: Colapso das comunicações, cidades isoladas, famílias lutam por sobrevivência

---

## 3. LÓGICA DE STATUS

- **Cada NPC**:  
  - `vivo`: 1 ou 0  
  - `morto`: 1 ou 0  
  - `zumbi`: 1 ou 0  
  - Exemplo:  
    - Ana Paula: 1,0,0 (Viva)  
    - Paulo Santos: 0,1,1 (Zumbi)  
- **Conversões**:  
  - Vivo → Morto → Zumbi (após contágio ou ataque)  
  - Não há respawn; tudo é físico, rastreado na árvore genealógica e localização

---

## 4. IMPACTO SOCIAL & FAMILIAR

- Núcleos familiares são o centro da resistência ou colapso:  
  - Alguns se refugiam juntos, outros se fragmentam por morte/zumbificação
  - Árvores genealógicas registram perdas, mutações, sobreviventes e desaparecidos
- Casas, ruas, bairros e cidades se reorganizam em função da ameaça zumbi  
  - Rotas de fuga, barricadas, zonas de loot, áreas de contágio

---

## 5. EVENTOS-CHAVE

- **Dia -30**: Primeiros sintomas em bairro periférico de Megacenter (E1)
- **Dia -27**: Família 0028 perde dois membros em ataque noturno; registro genealógico atualizado
- **Dia -20**: Cidade Porto Azul (E2) fecha fronteiras, cruzeiro MVVM Lux interceptado por zumbis no mar
- **Dia -15**: Facção dos Hackers cria primeira rede privada de comunicação entre bairros em quarentena
- **Dia -10**: Bairro Sul (E3) perde 40% da população em surto acelerado
- **Dia -5**: Piratas saqueiam navios de fuga; ilhas viram refúgio e zona de mercado negro
- **Dia -1**: Família 00096 reporta única sobrevivente após invasão total na Rua do Mercado

---

## 6. CONSOLIDAÇÃO & AUDITORIA

- Todos eventos rastreados por data, local, família, status dos NPCs
- Auditoria garante:  
  - Nenhum NPC sem casa, família ou status  
  - Nenhuma cidade/bairro/rua sem população ou função  
  - Todas mortes e conversões em zumbi registradas na árvore genealógica, casa e rota
- Estrutura pronta para evoluir para Dia 0 (início da infestação total e sobrevivência)

---

**Este é o Marco 0 do universo MVVM:  
Base sólida para o início da sobrevivência, expansão narrativa, auditoria e simulação zumbi.  
Pronto para subir e consultar!**