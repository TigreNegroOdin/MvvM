# Bairro: Central
- Cidade: Megacenter
- População: 5.200
- Ruas: 16
- Fronteiras: Bairro Sul, Estação Ferroviária, Mercado Central
- Facções: Sindicato dos Trabalhadores, Facção dos Hackers