# Casa: 001
- Rua: Principal
- Moradores: 4
- Itens de loot: 2
- Estado: Habitada