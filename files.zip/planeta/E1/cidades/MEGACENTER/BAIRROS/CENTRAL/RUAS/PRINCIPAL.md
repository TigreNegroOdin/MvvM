# Rua: Principal
- Bairro: Central
- Casas: 60
- Itens de loot: 18
- Fronteiras: Rua do Mercado, Avenida da Estação