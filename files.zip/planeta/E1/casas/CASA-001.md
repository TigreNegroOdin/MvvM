# Casa: 001
- Rua: Principal
- Bairro: Central
- Cidade: Megacenter
- Estado: E1
- Moradores: Ana Paula, Paulo Santos, Júlia Santos, Carlos Santos
- Status: 2 vivos, 1 zumbi, 1 desaparecido
- Loot: 2 (Livro, Café)