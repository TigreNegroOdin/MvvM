# 🌍 MVVM — UNIVERSO ZUMBI, VIDA, MEMÓRIA E DESTRUIÇÃO

---

## 1. CONTEXTO & LINHA DO TEMPO RAIZ

- **Ano base:** 2045
- **Evento Marco 0:** Surto global de doença zumbi, colapso social, início da infestação
- **Regra:** Nada se spawna, tudo se destrói, tudo se recria fisicamente
- **Estados:** E1 a E7, continente médio (50.000 km²), cercado por oceano e ilhas perdidas

---

## 2. ESTRUTURA POPULACIONAL

- **NPCs IA:** 500.000 (todos nomeados, cada um em casa/família/rua/bairro/cidade/estado)
- **Estados:** 7
- **Cidades:** 35
- **Bairros:** 140
- **Ruas:** 2.100
- **Casas:** 125.000
- **Núcleos familiares:** 130.000
- **Cada NPC tem status:**
  - `vivo`: 1 ou 0
  - `morto`: 1 ou 0
  - `zumbi`: 1 ou 0
  - Exemplo: Ana Paula (1 vivo, 0 morto, 0 zumbi); Paulo (0 vivo, 1 morto, 1 zumbi)
- **Distribuição:** Estados maiores têm mais cidades/bairros/ruas/casas/NPCs  
- **Relação familiar:** Todos NPCs têm núcleo, família, ligação genealógica

---

## 3. LOOT, OBJETOS & ROTAS

- **Loot:** 48.000 itens únicos, distribuídos por casas/ruas/bairros/cidades
- **Objetos:** Armas, comida, ferramentas, veículos, itens de sobrevivência
- **Rotas:** Todas ruas conectam casas, bairros, cidades, estados; cada NPC tem trajeto lógico, sem “flutuar”

---

## 4. ÁRVORE GENEALÓGICA MUNDIAL

- Cada família tem registro completo de membros, casas, relações (pai, mãe, filho, avô, primo, etc)
- Eventos familiares: doença, morte, fuga, conversão em zumbi, sobrevivência
- Núcleos ligados por ID, referência cruzada entre NPCs
- Exemplo:
  - Núcleo 00001: Ana Paula (mãe), Paulo (filho/zumbi), Júlia (filha), Carlos (avô)

---

## 5. EVENTOS & LINHA DO MARCO 0 (Doença/Zumbis)

- **Dia -30:** Primeiros casos de doença misteriosa
- **Dia -20:** Primeiros mortos ressurgem como zumbis
- **Dia -10:** Estado de emergência, cidades fecham fronteiras
- **Dia -5:** Facções armadas, fuga para ilhas e cruzeiros
- **Dia -1:** Infestação atinge bairros centrais, caos total
- **Dia 0:** Colapso, NPCs divididos entre vivos, mortos, zumbis

---

## 6. MODELO DE NPC

````markdown name=planeta/E1/npcs/PERS-E1-000001.md
# NPC: Ana Paula

- ID: PERS:E1-000001
- Estado: E1
- Cidade: Megacenter
- Bairro: Central
- Rua: Principal
- Casa: 001
- Núcleo Familiar: 00001
- Status: 1 vivo, 0 morto, 0 zumbi
- Inventário: Celular, Café, Livro
- Memórias:
  - Dia -30: Dormiu mal por barulho dos trens.
  - Dia -20: Paulo adoeceu, Ana cuidou dele.
  - Dia -10: Júlia desapareceu após ataque zumbi.
  - Dia 0: Refugiada na estação, sobreviver virou prioridade.