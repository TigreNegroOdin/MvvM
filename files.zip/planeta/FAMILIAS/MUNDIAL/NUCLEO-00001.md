# Núcleo Familiar 00001
- Membros: Ana Paula (mãe), Paulo Santos (filho/zumbi), Júlia Santos (filha/desaparecida), Carlos Santos (avô)
- Casa: 001 / Rua: Principal / Bairro: Central / Cidade: Megacenter / Estado: E1
- Eventos:
  - Dia -20: Paulo infectado, Ana cuidou
  - Dia -10: Júlia desapareceu
  - Dia 0: Família dividida, Carlos ferido