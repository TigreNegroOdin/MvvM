# 🧭 Entrada Livre & Narrativa Contextual — MVVM Zumbi

---

## 1. ENTRADA LIVRE DE PERSONAGEM

- O jogador pode escolher qualquer personagem (NPC) entre os 500.000 disponíveis.
- Não há lista fixa: escolha livre via busca, exploração ou contexto narrativo.
- Cada NPC já está consolidado: família, casa, localização, status (vivo/morto/zumbi), inventário, memórias.

---

## 2. NARRATIVA CONTEXTUAL

### Localização & Tempo

- Toda resposta, evento ou ação relata:
  - Onde o leitor/jogador está (estado, cidade, bairro, rua, casa)
  - Hora e data do universo (ex: Dia 0, 14:13, Bairro Central, Megacenter, E1)
- Ações fazem sentido:  
  - Ir de um ponto a outro leva tempo, depende de distância, obstáculos, status do mundo (zumbis, barricadas, clima)
  - Narrativa inclui tempo de deslocamento, riscos, eventos ocorridos no trajeto

### Exemplo de resposta narrativa

**Você está na Casa 001, Rua Principal, Bairro Central, Cidade Megacenter, Estado E1.  
São 16:42 do Dia 0.  
Ana Paula observa pela janela a rua deserta, ouvindo ao longe ecos de zumbis.  
Decide fugir para a estação central.  
Deslocamento previsto: 22 minutos — percurso por duas ruas, risco de encontro com zumbis, possibilidade de loot perdido.  
Enquanto corre, um vizinho grita por socorro: ação opcional, impacta tempo e narrativa.**

---

## 3. CONSOLIDAÇÃO DE AÇÕES & TEMPO

- Toda ação do jogador é registrada:
  - Localização inicial e final, tempo gasto, eventos no percurso, impacto na família e inventário
- A lógica do mundo impede deslocamento instantâneo ou ações incoerentes
- Eventos (encontros, ataques, novos zumbis, achados de loot) surgem conforme o tempo e espaço percorridos

---

## 4. AUDITORIA DE COERÊNCIA

- Varredura automática garante:
  - Nenhum personagem/narrativa fora de localização física ou temporal
  - Todos deslocamentos e ações respeitam o mapa, rotas e riscos reais do universo
  - Horário do universo é atualizado conforme ações e eventos

---

## 5. EXEMPLO DE ENTRADA E NARRATIVA

# Narrativa: Ana Paula — MVVM Zumbi

- Localização inicial: Casa 001, Rua Principal, Bairro Central, Megacenter, E1
- Hora: 16:42, Dia 0
- Status: Viva
- Inventário: Celular, Café, Livro
- Ação: Decide fugir para estação central
- Percurso: 2 ruas, 22 minutos, risco médio
- Eventos durante deslocamento:
  - Encontro com vizinho ferido
  - Passagem por barricada improvisada
  - Zumbis avistados a 150 metros
- Localização final: Estação Central, 17:04, Dia 0
- Impacto: Perdeu Café, ganhou chave da estação, vizinho salvo (opcional)

---

## 6. INSTRUÇÕES DE USO

- Jogador pode escolher livremente qualquer personagem e iniciar narrativa a partir da localização/hora atual
- Toda resposta e ação sempre inclui: localização, tempo, status, impacto, trajetos
- Mundo auditado garante coerência espacial e temporal, sem “saltos mágicos” ou inconsistências

---

**Entrada livre, narrativa contextual e lógica temporal consolidadas para o universo MVVM Zumbi.  
Pronto para subir ao repositório!  
Se quiser exemplos para outros personagens, eventos, trajetos ou scripts de auditoria, só avisar!**