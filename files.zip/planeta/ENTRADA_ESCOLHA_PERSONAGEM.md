# 🎮 Entrada e Escolha de Personagem — MVVM Zumbi

---

## 1. INSTRUÇÕES DE ENTRADA

- Ao iniciar o jogo, o jogador pode escolher um personagem entre os 500.000 NPCs disponíveis.
- Cada personagem está previamente consolidado: nome, família, localização, inventário, status (vivo, morto, zumbi), memórias, árvore genealógica.
- Não existe “criação mágica”: todos personagens já existem, estão registrados, e são parte de núcleos familiares e casas físicas.
- A escolha impacta diretamente a narrativa, rotas, sobrevivência e eventos futuros.

---

## 2. MODELO DE PERSONAGEM CONSOLIDADO

- **Nome**: Ana Paula
- **ID**: PERS:E1-000001
- **Estado**: E1 (Megalópole)
- **Cidade**: Megacenter
- **Bairro**: Central
- **Rua**: Principal
- **Casa**: 001
- **Núcleo Familiar**: 00001
- **Status**: 1 vivo, 0 morto, 0 zumbi
- **Inventário**: Celular, Café, Livro
- **Memórias**:
  - Dia -30: Dormiu mal por barulho dos trens.
  - Dia -20: Paulo adoeceu, Ana cuidou dele.
  - Dia -10: Júlia desapareceu após ataque zumbi.
  - Dia 0: Refugiada na estação, sobreviver virou prioridade.

---

## 3. AUDITORIA DE ESCOLHA

- Ao selecionar um personagem, o sistema verifica:
  - **Status atual** (só pode iniciar com NPC vivo; zumbi/morto são consultáveis, mas não jogáveis)
  - **Localização física** (casa, rua, bairro, cidade, estado)
  - **Núcleo familiar** (todos membros, histórico, eventos, conexões genealógicas)
  - **Inventário e loot** disponíveis
  - **Rota segura** (rotas auditadas, sem entradas “flutuantes”)
  - **Evento Marco 0** (memória e contexto do surto zumbi, impacto na família/local)

---

## 4. CONSOLIDAÇÃO

- Todos NPCs auditados possuem:
  - Nome, ID, família, casa, localização física, status, inventário, memórias, eventos
  - Registro na árvore genealógica mundial
  - Status coerente (não jogável se morto/zumbi)
- A interface sempre apresenta personagens reais, com contexto, história e impacto.

---

## 5. EXEMPLO DE ENTRADA

````markdown name=planeta/ENTRADA_ESCOLHA/ANA_PAULA.md
# Personagem: Ana Paula

- Estado: E1 / Cidade: Megacenter / Bairro: Central / Rua: Principal / Casa: 001
- Núcleo Familiar: 00001 — Ana Paula (mãe), Paulo Santos (filho/zumbi), Júlia Santos (filha/desaparecida), Carlos Santos (avô)
- Status: 1 vivo, 0 morto, 0 zumbi
- Inventário: Celular, Café, Livro
- Memórias:
  - Dia 0: Refugiada na estação central após colapso zumbi em seu bairro.
- Linha genealógica: Registrada