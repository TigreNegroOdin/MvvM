#!/bin/sh
cat \
  '/mnt/data/MASTER_BIBLIA_vFinal_P1.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P2.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P3.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P4.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P5.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P6.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P7.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P8.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P9.txt' \
  '/mnt/data/MASTER_BIBLIA_vFinal_P10.txt' \
> /mnt/data/MASTER_BIBLIA_vFinal_FULL.txt
echo 'Concatenacao concluida: /mnt/data/MASTER_BIBLIA_vFinal_FULL.txt'
