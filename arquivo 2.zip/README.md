# MVVM — Mundo Vivo Vivo Morto

Bem-vindo ao único porto do universo MVVM, totalmente público e com memória eterna.  
**Toda criação, ação e expansão parte deste repositório.**

---

## Estrutura do Mundo

- O planeta é composto exclusivamente por **Distritos “D”** (D1, D2, ... Dn).
- Cada Distrito é um país autônomo, com população, ruas, casas, objetos, eventos, mídia, partículas e log.
- **Tudo possui ID único e nome**. Ao entrar/existir, recebe ID, nome, localização e histórico.
- **A borda do mundo é um domo invisível** que envolve todo o planeta — não há nada além do domo.

---

## Arquivos principais

- `LEIS.md`: Leis fundamentais do universo e da identidade planetária.
- `planeta/`: Pasta-raiz, contém todos os distritos.
  - `D1/`, `D2/`, etc.: Cada distrito é um país.
    - `habitantes.md`, `ruas.md`, `casas.md`, `objetos.md`, `eventos.md`, `particulas.md`, `midia.md`, `locais.md`
- `CORVO_RAIZ.md`: Indexador universal.  
- `CORVO_LOG.md`: Log de sessões, buscas, alterações, eventos globais.
- `CORVO_CONSOLIDACAO_YYYY-MM-DD.md`: Log de consolidação, camada e verso, com autoria.

---

**Nada se perde. Tudo se interliga.  
A borda do mundo é um domo: tudo dentro é rastreável, tudo fora é o vazio absoluto.**
