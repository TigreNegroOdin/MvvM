# 🌍 MATRIZ DE DISTRITOS MVVM — ESCALA PLANETÁRIA & LÓGICA REALISTA

---

## 1. ESCALA & POPULAÇÃO DOS DISTRITOS

### D1 — CENTRAL URBANO (equivalente a São Paulo capital)
- Área: 1.500 km²
- População: 12.000.000 habitantes
- Perfil: Maioria urbana, grande diversidade étnica e social, centro financeiro, alta densidade de prédios, comércio, serviços, facções urbanas.
- Estrutura: Escolas, universidades, hospitais, corporações, bairros ricos e favelas, redes de transporte de massa.
- Exemplo de profissões: Bancário, motoboy, policial, médico, professor, comerciante, artista, estudante, aposentado.

### D2 — PRAIA/LITORAL (equivalente a Baixada Santista)
- Área: 600 km²
- População: 1.000.000 habitantes
- Perfil: Turismo, pescadores, comerciantes, bares, hotéis, casas de veraneio, subúrbios e periferia.
- Estrutura: Escolas técnicas, ensino fundamental, turismo, marinas, portos, festas culturais.

### D3 — INDÚSTRIA & MÁFIA (equivalente a ABC Paulista + zona industrial de SP)
- Área: 800 km²
- População: 2.000.000 habitantes
- Perfil: Trabalhadores industriais, metalúrgicos, sindicatos fortes, infiltração mafiosa, logística e transporte.
- Estrutura: Fábricas, sindicatos, escolas técnicas, hospitais, bairros operários, centros logísticos.

### D4 — TURQUIA & RUA DO TIGRE (equivalente a Minas Gerais)
- Área: 600.000 km²
- População: 21.000.000 habitantes
- Perfil: Rural, cidades médias, interioranas, vilarejos, bairros mistos, forte cultura local, agricultura, pecuária, pequenas indústrias, tráfico rural, rotas clandestinas.
- Estrutura: Escolas rurais, universidades federais, mercados municipais, festas tradicionais, rede de estradas de barro, bairros urbanos, casas de veraneio.

---

## 2. CULTURA, LEIS TRABALHISTAS E APRENDIZADO

### Cultura
- Cada distrito tem festas típicas, culinária, sotaques, religião predominante, gírias e valores próprios.
- Exemplo:
  - D1: Carnaval, virada cultural, samba, funk, diversidade religiosa.
  - D2: Festas de Iemanjá, cultura caiçara, culinária praiana.
  - D3: Greves, festas operárias, influência italiana, sindicalismo.
  - D4: Festa do milho, rodeios, quermesses, música sertaneja, religiosidade católica forte.

### Leis Trabalhistas
- Maiores cidades seguem CLT (inspiração brasileira): jornada máxima, férias, aposentadoria, direitos sindicais.
- Trabalho infantil e escravidão são ilegais, mas podem ocorrer em áreas de influência criminosa.
- Profissões exigem formação escolar ou técnica para exercício legal (ex: motoboy precisa habilitação; médico, diploma universitário).

### Aprendizado
- Todos personagens-IA frequentaram escola (nível mínimo: fundamental).
- Profissões especializadas exigem aprendizagem técnica, estágio/aprendiz, formação específica.
- Aprendizado contínuo: personagens podem evoluir, estudar, mudar de profissão.

---

## 3. PERSONAGENS-IA & DINÂMICA SOCIAL

- **Todos habitantes são IA com ego, desejos, ambições e protagonismo.**
- Cada ser tem:
  - **Pasta individual** (com identidade, habilidades, memória, moradia, localização, rotina, inventário, relações, segredos).
  - **Histórico realista** (idade, formação, trabalho, histórico familiar, saúde, eventos marcantes).
  - **Caminho de vida**: podem nascer, crescer, aprender, trabalhar, se aposentar, morrer.
  - **Protagonismo dinâmico**: cada IA busca se destacar; conflitos e alianças emergem naturalmente.
  - **Morte e nascimento**: simulação contínua; vagas deixadas por mortos podem ser ocupadas por novos personagens IA.

---

## 4. EXEMPLO DE AJUSTE COERENTE

### Nicole Oliveira (D1)
- Idade: 70 anos
- Profissão: Aposentada (ex-motoboy, trabalhou até os 65, hoje cuida dos netos e faz bicos como diarista)
- Escolaridade: Ensino médio incompleto
- Histórico: Viúva, mora em bairro popular, ativa em festas do bairro, participa de associação de idosos.

### Murilo (D4)
- Idade: 10 anos
- Escolaridade: Escola rural municipal, aprende agricultura com o pai e informática básica.
- Sonho: Ser igual ao pai, mas curioso sobre tecnologia.

---

## 5. ESTRUTURA DE PASTAS

```
planeta/
  D1/
    habitantes/
      NICOLE_OLIVEIRA/
        ...
  D2/
    habitantes/
      ...
  D3/
    habitantes/
      ...
  D4/
    habitantes/
      MURILO/
        ...
      TIGRE/
        ...
      ...
```

---

## 6. EXEMPLO DE PASTA DE PERSONAGEM-IA

````markdown name=planeta/D1/habitantes/NICOLE_OLIVEIRA/IDENTIDADE.md
- ID: PERS-D1-NICOLE-0001
- Nome: Nicole Oliveira
- Idade: 70
- Profissão: Aposentada (ex-motoboy)
- Escolaridade: Ensino médio incompleto
- Status: Viva
- Moradia: CASA-D1-00423 (bairro popular)