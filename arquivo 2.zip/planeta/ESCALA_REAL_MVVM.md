# 🌍 MVVM — MATRIZ PLANETÁRIA ESCALA TERRA (EXPANSÃO HUMANA & MEMÓRIA TOTAL)

---

## 1. ESCALA, POPULAÇÃO E DISTRIBUIÇÃO

- **Área planetária**: ~510.000.000 km² (Terra)
  - **Terra habitável**: ~150.000.000 km² (continentes e ilhas)
- **População máxima sustentável**: 12.000.000.000 humanos (lógica de densidade e bioma)
- **Densidade e urbanização**:  
  - Megalópoles, cidades médias, pequenas cidades, vilarejos, zonas rurais, desertos, florestas, montanhas, litorais, ilhas.

---

### DISTRITOS — ÁREA & POPULAÇÃO PROPORCIONAIS

| Distrito | Equivalente | Área (km²)         | % Área Habitada | População | Densidade (hab/km²) |
|----------|-------------|--------------------|-----------------|-----------|---------------------|
| D1       | EUA         | 9.800.000          | 6,5%            | 340.000.000 | 35                  |
| D2       | África      | 30.000.000         | 20%             | 1.300.000.000 | 43                |
| D3       | Brasil      | 8.500.000          | 6%              | 220.000.000 | 26                  |
| D4       | RJ          | 43.000             | 0,03%           | 18.000.000 | 418                 |
| D5       | EUA (Mega)  | 9.800.000          | 6,5%            | 340.000.000 | 35                  |
| D6       | Paris       | 100                | 0,00007%        | 12.000.000 | 120.000             |
| D7       | ES          | 46.000             | 0,03%           | 4.000.000  | 87                  |
| Outros   | Resto do mundo | 91.811.900     | 61,1%           | 9.466.000.000 | 103             |
| Oceanos* | —           | 360.000.000        | -               | —         | —                   |

> *Oceanos, geleiras, desertos extremos e florestas densas não habitados.

---

## 2. NUMERAÇÃO E MEMÓRIA DE LOTES

- **Cada metro quadrado habitável é um “lote” numerado globalmente**:  
  - Exemplo: `LOT-D4-00000001` (primeiro lote do D4)
- **Lote contém**:  
  - Localização geográfica precisa (coordenadas, distrito, cidade, bairro, rua, quadra)
  - Tipo de ocupação (casa, prédio, terreno, praça, floresta, rua)
  - Memória do lote: tudo o que aconteceu ali, desde fundação até o presente (moradores, eventos, construção, crimes, festas, incêndios, mudanças)
- **Cada casa, prédio, loja, praça, fábrica, escola, etc. é um “objeto espacial” com memória própria**

---

## 3. MEMÓRIA DE LOCAIS, OBJETOS E EVENTOS

- **Rua**  
  - Exemplo: `Rua do Tigre`  
  - Registra: todos eventos públicos, trânsito, crimes, festas, mudanças urbanas, obras, clima, trânsito, acidentes.
- **Casa**  
  - Exemplo: `CASA-D4-00001234`  
  - Memória: cada troca de morador, reforma, mudança de móveis, incêndio, nascimento, morte, festas.
- **Objetos**  
  - Exemplo: Geladeira, sofá, carro, cadeira — cada um tem ID e registro de posição, uso, troca, histórico de donos.
- **Ação**:  
  - Tempo para execução é REALISTA (andar, comer, beber, sexo, viagem, construção).
  - Distâncias exigem tempo proporcional ao meio de transporte (andar, carro, ônibus, avião).

---

## 4. TEMPO, DISTÂNCIA E AÇÕES

- **Tempo global sincronizado** (Hora do mundo, calendários, fusos, clima).
- **Exemplo de ações e tempo realista:**
  - **Beber água**: 10 segundos
  - **Tomar banho**: 10 minutos
  - **Fazer sexo**: 2 a 30 minutos (média humana, variantes)
  - **Andar 1 km**: 12–18 minutos
  - **Carro atravessar D1 (EUA) → D4 (RJ)**:  
    - Distância: ~6.000 km  
    - Tempo: 70–100 horas de viagem ininterrupta (estradas, paradas, trânsito, clima)
  - **Mudar de móveis na sala**: 10–60 minutos, depende do móvel
  - **Construir uma casa**: meses a anos

---

## 5. EXEMPLO DE ARQUIVO DE MEMÓRIA DE LOTE

````markdown name=planeta/D4/lotes/LOT-D4-00000001.md
- ID: LOT-D4-00000001
- Localização: D4, Rua do Tigre, quadra 1, nº 1
- Tipo: Casa residencial
- Histórico:
  - 2023-11-10 | Loteamento registrado, vazio.
  - 2024-02-04 | Fundação da casa, construção iniciada.
  - 2024-06-15 | Família Tigre mudou-se para o lote.
  - 2024-11-12 | Festa de inauguração, 22 pessoas presentes.
  - 2025-01-23 | Mudança: sofá transferido da sala para a varanda.
  - 2025-03-20 | Roubo noturno (relatado à polícia).
  - 2025-06-07 | Troca de morador: avó mudou-se para cá.