# MÍDIA — DISTRITO D1

## TV
- 2025-09-06T19:00:00Z | Canal Central  
  Manchete: “Novos relatos de reanimação zumbi no distrito D1. Autoridades alertam para permanência em casa.”

## Rádio
- 2025-09-06T08:00:00Z | Rádio D1  
  Boletim: “Ventos fortes previstos para o início da noite. Cuidado ao sair de casa.”
---