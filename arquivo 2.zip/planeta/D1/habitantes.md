# HABITANTES DO DISTRITO D1 (PAÍS D1)

## [PERS-D1-000001]
- Nome: Nicole Oliveira
- Idade: 70
- Papel: Idoso
- Ocupação: Motoboy
- Skills: Programação, direção, tiro
- Home: CASA-D1-000001
- Inventário: ITEM-D1-000001
- Data de criação: 2025-09-06

## [PERS-D1-000002]
- Nome: Mateus Martins
- Idade: 90
- Papel: Idoso
- Ocupação: Agricultor
- Skills: Culinária
- Home: CASA-D1-000002
- Inventário: ITEM-D1-000002
- Data de criação: 2025-09-06

## [PERS-D1-000003]
- Nome: Sara Lopes
- Idade: 27
- Papel: Professora
- Ocupação: Ensino Fundamental
- Home: CASA-D1-000003
- Inventário: ITEM-D1-000003, ITEM-D1-000004
- Data de criação: 2025-09-06

---