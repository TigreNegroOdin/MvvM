# CASAS DO DISTRITO D1

## [CASA-D1-000001]
- Endereço: Avenida Central, nº 1
- Rua: RUA-D1-000001
- Moradores: PERS-D1-000001

## [CASA-D1-000002]
- Endereço: Avenida Central, nº 2
- Rua: RUA-D1-000001
- Moradores: PERS-D1-000002

## [CASA-D1-000003]
- Endereço: Rua das Palmeiras, nº 1
- Rua: RUA-D1-000002
- Moradores: PERS-D1-000003

---