# DISTRITO D1 — ESTRUTURA RAIZ

## Descrição Geral
Distrito D1 é um dos países sob o domo do mundo MVVM.  
Inclui praias, áreas urbanas, zonas rurais, casas, bairros, população diversa, infraestrutura, objetos, veículos e profissões.

---

## 1. HABITANTES

Inclui todos os residentes, visitantes e NPCs do distrito (detalhe raiz: ID, nome, localização, profissão, inventário, histórico, etc).

### Exemplo:
- [PERS-D1-000001] Nicole Oliveira — Motoboy, 70 anos, casa: CASA-D1-000001
- [PERS-D1-000002] Mateus Martins — Agricultor, 90 anos, casa: CASA-D1-000002
- [PERS-D1-000003] Sara Lopes — Professora, 27 anos, casa: CASA-D1-000003

---

## 2. CASAS E PRAIAS

### 2.1 Casas
- [CASA-D1-000001] Rua Central, nº 1 — Morador: Nicole Oliveira
- [CASA-D1-000002] Rua Central, nº 2 — Morador: Mateus Martins
- [CASA-D1-000003] Praia Azul, nº 1 — Morador: Sara Lopes

### 2.2 Praia
- [LOC-D1-0002] Praia Azul  
  - Coordenadas: -23.555000,-46.630500,0  
  - Casas de praia: [CASA-D1-000003] a [CASA-D1-000050]
  - Areia: [AREIA-D1-000001] a [AREIA-D1-1000000]
  - Barracas, quiosques, barcos, etc.

---

## 3. RUAS E BAIRROS

- [RUA-D1-000001] Avenida Central — Casas: 1 a 5000
- [RUA-D1-000002] Rua das Palmeiras — Casas: 5001 a 5800
- [RUA-D1-000003] Avenida Praia Azul — Casas: 5801 a 6000

---

## 4. OBJETOS DOMÉSTICOS

### Exemplo:
- [OBJ-D1-000001] Geladeira Brastemp, CASA-D1-000001
- [OBJ-D1-000002] Sofá de couro, CASA-D1-000001
- [OBJ-D1-000003] Rádio antigo, CASA-D1-000001
- [OBJ-D1-000004] Mesa de jantar, CASA-D1-000002
- [OBJ-D1-000005] Kit Médico, CASA-D1-000002
- [OBJ-D1-000006] Livro didático, CASA-D1-000003

---

## 5. OBJETOS PROFISSIONAIS

### Exemplo:
- [OBJ-D1-PRF-000001] Capacete de Motoboy, Nicole Oliveira
- [OBJ-D1-PRF-000002] Enxada agrícola, Mateus Martins
- [OBJ-D1-PRF-000003] Notebook MVVMBook, Sara Lopes
- [OBJ-D1-PRF-000004] Quadro branco, Escola Fundamental D1

---

## 6. VEÍCULOS

### Exemplo:
- [CAR-D1-000001] Moto Honda CG — Proprietário: Nicole Oliveira, CASA-D1-000001
- [CAR-D1-000002] Caminhonete Rural — Proprietário: Mateus Martins, CASA-D1-000002
- [CAR-D1-000003] Van Escolar — Escola Fundamental D1

---

## 7. MEMÓRIA DE PARTÍCULAS E OBJETOS

Cada item/partícula tem:
- ID único
- Nome/tipo
- Localização atual (coordenadas, dentro de casa, rua, praia, etc)
- Histórico de posições/movimentações (quem, quando, motivo)
- Estado (intacto, usado, quebrado, etc)

---

## 8. SUPERFÍCIE (VISÍVEL AO JOGADOR)
- O jogador vê apenas resumos, ex:  
  - “Você entra numa casa simples na praia, há cheiro de maresia, um rádio toca música antiga.”
  - “Nicole chega de moto e deixa um capacete sobre a mesa.”

---

## 9. RAIZ (DETALHADO, INVISÍVEL)
- Tudo registrado com IDs, histórico completo, localização exata, vínculos e motivos para cada ação e estado.

---

> Para expandir:  
> - Prossiga adicionando mais habitantes, casas, objetos, veículos, profissões, ruas, praias, etc, sempre com ID e memória.
> - Crie D2, D3... com mesmo padrão.
> - Para cada ação (ex: mover areia, usar objeto), atualize a memória invisível na camada raiz.
